<?php
	session_destroy();
	echo "<a href='index.php'>back to home</a>";
?>